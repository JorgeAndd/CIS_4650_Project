Name: Jorge Luiz Andrade
#0906139

plex
Scanner: lex file

pbison
Grammar: Bison file

nodes.h nodes.c
Source file containing code for syntax tree generation


makefile
Makefile for building the program. Can be run with make, make all or make cflatc

1.cb 2.cb 3.cb 4.cb 5.cb
Test codes
