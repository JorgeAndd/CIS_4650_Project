Name: Jorge Luiz Andrade
#0906139

Final Project

plex
Scanner: lex file

pbison
Grammar: Bison file

nodes.h nodes.c
Source code and header for syntax tree generation

nodeStructs.h
Stores structs for representing the syntax tree

toXml.h toXml.c
Source code and header for printing the syntax tree in XML format

symbolTable.h symbolTable.c
Source code and header for building the symbol table from the syntax tree

semanticAnalysis.h semanticAnalysis.c
Source code and header for semantic analysis on syntax tree

codeGeneration.h codeGeneration.c
Source code and header for translate code from intermediate representation to 
MIPS assembly

makefile
Makefile for building the program. Can be run with make, make all or make cflatc

[12345678].cb
Test codes
